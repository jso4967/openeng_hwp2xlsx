from docx import Document
import classes, model_core

def extract_problem_set(docx_path):
    '''
    일반 파일로부터 prolem_set의 형식에 맞게 데이터 추출하는 메소드

    :param docx_path: 일반 파일의 docx 버전
    :return: 일반 파일의 모든 것을 problem_set으로 반환
    '''
    ROW_START = 0
    ROW_END = 40

    document = Document(docx_path)
    flag = ""

    for index in range(0, int((document.tables[0]._cells.__len__() - 1)/2)):  # 모든 열

        # entry = document.tables[0].cell(0, index * 41).text  # 현재 열의 좌측 셀
        entry = document.tables[0].cell(0, index).text
        entry = entry.strip()
        current_problem_number = 0

        if flag.__len__() == entry.__len__():  # 전 셀의 내용과 동일하다면 건너띄기
            continue
        # 전 셀의 내용과 동일하지 않다면
        flag = entry

        # 데이터 추출에 필요 없는 부분 거르기
        if entry.find("Words & Phrases") >= 0:  # Words & Phrases로 시작한다면 다음 첫 문장 살피기
            print("Words & Phrases")
            continue
        elif entry.find("문제") == 0:  # 문제로 시작한다면 다음 첫 문장 살피기
            print("문제 및 보기")
            continue
        elif entry.find("정답 해결)") == 0:  # 정답 해결)로 시작한다면 다음 첫 문장 살피기
            print("정답 해석")
            continue
        elif entry.find("영치법 영한치환") >= 0:
            print("영치법 영한치환")
            continue
        elif entry.find("영치법 한영치환") >= 0:
            print("영치법 한영치환")
            continue

        # 데이터를 추출해야 하는 부분
        if entry.find("영어 원문 분석") >= 0:

            # 문제 번호 찾기
            if entry[0].isdecimal():
                current_problem_number = entry[0]

            #

            print("영어 원문 분석")

            continue

        elif entry.find("영문 해석") >= 0:
            # 문제 번호 찾기
            if entry[0].isdecimal() == current_problem_number:  # 영어 원문 분석과 문제번호가 짝인가?
                pass
            #
            print("영문 해석")
            continue

        else :  # 규칙에 맞지 않는 상황
            # TODO : Exception 작성하기
            continue

        # document.tables[0].cell(0, index * 41 + 40).text  #  현재 열의 추측 셀
