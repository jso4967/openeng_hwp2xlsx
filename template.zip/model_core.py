import pyautogui
from datetime import datetime
import time, ctypes

def convert_hwp2docx(path):
    __path = path
    #  파일 세팅
    ctypes.windll.Shell32.ShellExecuteW(None, 'open', __path, None, None, 1)
    print(1, datetime.now())
    time.sleep(5)

    # 다른 이름으로 파일 저장하기 전 단계
    pyautogui.hotkey('alt', 'f')
    print(2, datetime.now())

    # 다른 이름으로 파일 저장하기
    pyautogui.hotkey('alt', 'v')
    print(3, datetime.now())

    # 파일 형식 지정하기
    pyautogui.hotkey('alt', 't')
    print(4, datetime.now())

    # 파일 형식 지정하기2
    for i in range(20):
        pyautogui.hotkey('up')

    pyautogui.hotkey('down')
    pyautogui.hotkey('down')
    pyautogui.hotkey('down')
    pyautogui.hotkey('enter')
    print(5, datetime.now())

    # 파일 저장하기
    pyautogui.hotkey('alt', 'd')
    print(6, datetime.now())

    # 파일 저장 확인
    pyautogui.hotkey('c')

    # 열었던 프로그램 종료
    pyautogui.hotkey('alt', 'f4')

    time.sleep(3)
    print("Convert Succeeded")

def delete_empty_space(phrases):
    '''
    :param phrases: phrase의 집합들
    ex) current_eng_phrasess, curren_kor_phrases와 같이

    :return: 각 집합 안에 존재하는 비어있는 공간을 지운다.
    ex) ['ㅁ', 'ㅠ', '', 'ㅊ'] -> ['ㅁ','ㅠ','ㅊ']
    '''

    i = phrases.__len__() - 1
    while i >= 0:
        phrases[i] = phrases[i].strip()
        if phrases[i] == "":
            del phrases[i]
        i -= 1

    return phrases

def does_start_with_circled_number(text, current_option_number):
    '''

    :param text: 첫 글자가 선지번호인지 아닌지 체크하고자 하는 문장
    :param current_option_number: 선지번호의 연속성을 이용하여 값 검증을 하기 위한 값
    :return: None인 경우 선지번호로 시작하지 않음을 뜻함 /
            (message, i)인 경우, 선지번호로 시작함을 뜻함 : 디버깅을 위한 message와,
                current_option_number 업데이트를 위한 i 값 반환
    '''
    option_number = 0xe291a0
    message = ""

    for i in range(50):

        # 헥스코드를 이용하여 선지번호인지 체크

        # 20인 부분에서 21인 부분으로 점프 (1부터 20까지는 연속적인데, 20과 21의 유니코드 값이 불연속적이다.)
        # 관련 링크 : https://unicode-table.com/en/2473/
        if option_number == 14848436:
            option_number += 63453

        # 위와 동일한 이유 : https://unicode-table.com/en/32B1/
        if option_number == 14911904:
            option_number += 273

        is_option_number = text[:2].find(bytes.fromhex(str(hex(option_number)[2:])).decode('utf-8'))
        if is_option_number >= 0 and (current_option_number == 0 or current_option_number + 1 == i):
            message = "첫 문자가 선지 번호인 경우 : " + text
            return (message, i)

        # 올바른 선지번호가 아닌 경우 : 문장에 선지번호는 존재하나, 이전 번호와 순서가 맞지 않음
        elif is_option_number >= 0 and current_option_number + 1 != i:
            return None, current_option_number

        option_number += 1
    return None, current_option_number








