from tkinter import *
from tkinter.ttk import *
import controller


class MyFrame(Frame):
    def __init__(self, master):
        Frame.__init__(self, master)

        self.master = master
        self.master.title("HWPConverter")
        self.pack(fill=BOTH, expand=True)

        #TODOLIST : 사진 처럼 다듬기
        photo = PhotoImage(file="left_logo.png")
        lbpng = Label(self, image=photo)
        lbpng.image = photo
        lbpng.pack()

        # 모드 선택
        framemodechoice = Frame(self)
        lblModeChoice = Label(framemodechoice, text="Step 0. Select a mode for convert")
        lblModeChoice.pack(padx=10, side=LEFT, pady=10)

        comboModeChoice = Combobox(framemodechoice, textvariable=str)
        comboModeChoice['values'] = ('HWP2DOCX', 'HWP2XLSX', 'DEBUG')
        comboModeChoice.current(0)
        comboModeChoice.pack(padx=10, side=RIGHT, pady=10)

        framemodechoice.pack(fill=X, pady=(0,30))

        # TODO : 버튼 눌렀을 때 새로 생기는 방식 고려

        # 변환할 파일 설정
        framelb1 = Frame(self)
        lblFileToConvert = Label(framelb1, text="Step 1. Select a file to convert from your Disk", width=100)
        lblFileToConvert.pack(padx=10, side=LEFT)
        framelb1.pack(fill=X)

        framechoice1 = Frame(self)
        entryFileToConvert = Entry(framechoice1)
        entryFileToConvert.pack(fill=X, side=LEFT, padx=10, expand=True)

        btnBrowse1 = Button(framechoice1, text="Browse",
                            command=lambda: controller.browse_button_pressed(self, entryFileToConvert,
                                                                             "FileBrowse"))
        btnBrowse1.pack(fill=X, side=RIGHT, padx=10)
        framechoice1.pack(fill=X, pady=(0, 30))

        # 저장 폴더 설정
        framelb2 = Frame(self)
        lblFolderToSave = Label(framelb2, text="Step 2. Select a directory to save", width=100)
        lblFolderToSave.pack(padx=10, side=LEFT)
        framelb2.pack(fill=X)

        framechoice2 = Frame(self)
        entryFolderToSave = Entry(framechoice2)
        entryFolderToSave.pack(fill=X, side=LEFT, padx=10, expand=True)

        btnBrowse2 = Button(framechoice2, text="Browse",
                            command=lambda: controller.browse_button_pressed(self, entryFolderToSave, "FolderBrowse"))
        btnBrowse2.pack(fill=X, side=RIGHT, padx=10)
        framechoice2.pack(fill=X, pady=(0, 30))

        ### 버튼 눌렀을 때, 활성화 되는 방식

        # comboModeChoice.get() == 'HWP2XLSX' 혹은 'DEBUG'일 때 활성화
        framelb3 = Frame(self)

        lblFile2ToConvert = Label(framelb3, text="Step 3. Select a phrase-file to convert", width=100)
        # 여기서 phrase-file은 영치법 파일을 의미한다.

        lblFile2ToConvert.pack(padx=10, side=LEFT)
        framelb3.pack(fill=X)

        framechoice3 = Frame(self)
        entryFile2ToConvert = Entry(framechoice3)
        entryFile2ToConvert.state(['disabled'])
        entryFile2ToConvert.pack(fill=X, side=LEFT, padx=10, expand=True)

        btnBrowse3 = Button(framechoice3, text='Browse',
                            command=lambda: controller.browse_button_pressed(self, entryFile2ToConvert, "DocxFileBrowse"))
        btnBrowse3.state(['disabled'])
        btnBrowse3.pack(fill=X, side=RIGHT, padx=10)
        framechoice3.pack(fill=X, pady=(0, 30))

        def update_status(entryFile2ToConvert, btnBrowse3):
            if comboModeChoice.get() == "HWP2DOCX":
                entryFile2ToConvert.state(['disabled'])
                btnBrowse3.state(['disabled'])
            else:
                    entryFile2ToConvert['state'] = 'normal'
                    btnBrowse3['state'] = 'normal'

        comboModeChoice.bind("<<ComboboxSelected>>", lambda _ : update_status(entryFile2ToConvert, btnBrowse3))

        # comboModeChoice.bind("<<ComboboxSelected>>", lambda _ :print("SELECTED!"))

        # 상태바
        frameprogressbar = Frame(self)
        progress_bar = Progressbar(frameprogressbar, orient='horizontal', mode='determinate')
        progress_bar.pack(fill=X)
        frameprogressbar.pack(fill=X, padx=10)

        # 변환
        framecontrol = Frame(self)
        btnConvert = Button(framecontrol, text="Convert",
                            command=lambda: controller.convert_button_pressed(self, entryFileToConvert,
                                                                              comboModeChoice.get(),
                                                                              entryFolderToSave,
                                                                              entryFile2ToConvert))

        btnConvert.pack(side=RIGHT, padx=10)
        # 취소
        btnCancel = Button(framecontrol, text="Cancel", command=lambda:Frame.quit(self))
        btnCancel.pack(side=RIGHT, padx=10)
        framecontrol.pack(fill=X, pady=20)

def main():
    root = Tk()
    root.geometry("400x450+1200+100")
    root.resizable(False, True)
    app = MyFrame(root)
    root.mainloop()


if __name__ == '__main__':
    main()